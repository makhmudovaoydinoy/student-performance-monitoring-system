# Talabalar o'zlashtirishini kuzatish va erta ogohlantirish tizimi

Baho va davomat asosida xavf guruhidagi talabalarni avtomatik aniqlaydigan va mas'ul shaxslarni ogohlantiradigan veb-tizim.
**Stek:** FastAPI · SQLAlchemy · PostgreSQL · JWT/bcrypt · HTML/CSS/JS + Chart.js · Docker · Google Cloud Run.

## Tez ishga tushirish

### A) Docker (PostgreSQL bilan, tavsiya etiladi)
```bash
docker compose up --build
# boshqa terminalda demo ma'lumot:
docker compose exec app python -m app.seed
```
Oching: http://localhost:8080 · API hujjati: http://localhost:8080/docs

### B) Lokal (SQLite, Docker'siz)
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
cd backend
python -m app.seed                                      # demo ma'lumot (ixtiyoriy)
uvicorn app.main:app --reload --port 8080
```

**Demo kirish:** `admin / Admin123!` · `teacher1 / Teacher123!` · `teacher2 / Teacher123!` (ishlab chiqarishda albatta almashtiring).

### C) PostgreSQL'ni qo'lda (SQL fayllar bilan)
```bash
psql -U postgres -f database/00_create_database.sql
psql -U postgres -d student_monitoring -f database/schema.sql
psql -U postgres -d student_monitoring -f database/seed.sql       # namunaviy ma'lumot
psql -U postgres -d student_monitoring -f database/queries.sql    # asosiy SELECT'lar
```

## Testlar
```bash
cd backend && pytest -q
```

## Loyiha tuzilmasi
```
student-performance-monitoring-system/
├── backend/app/            # FastAPI: main, config, database, models, schemas, security, deps, seed
│   ├── routers/            # auth, users, academic, students, grades, risk, notifications, dashboard
│   └── services/           # calculator, risk, risk_service, notifier, queries
├── backend/tests/          # pytest
├── frontend/               # index.html, css/style.css, js/app.js
├── database/               # 00_create_database.sql, schema.sql, seed.sql, queries.sql
├── docs/                   # hujjatlar + diagrams/*.puml (UML, ER)
├── Dockerfile · docker-compose.yml · requirements.txt · .env.example · .gitignore
└── .github/workflows/ci.yml
```

## Asosiy API (to'liq ro'yxat: `/docs`)
| Metod | Yo'l | Huquq |
|---|---|---|
| POST | `/api/auth/login` | hamma |
| GET/POST/DELETE | `/api/users` | ADMIN |
| GET/POST/PUT/DELETE | `/api/groups`, `/api/subjects` | o'qish: hamma, yozish: ADMIN |
| POST | `/api/enrollments`, `/api/enrollments/group` | ADMIN |
| GET/POST/PUT/DELETE | `/api/students` | o'qish: scope bo'yicha, yozish: ADMIN |
| POST/GET/DELETE | `/api/grades` | ADMIN, fan o'qituvchisi |
| GET, POST | `/api/attendance`, `/api/attendance/bulk` | ADMIN, fan o'qituvchisi |
| GET | `/api/risk/at-risk`, `/api/risk/export.csv` | scope bo'yicha |
| POST | `/api/risk/recalculate` | ADMIN |
| POST | `/api/risk/scheduler-run` | `X-Scheduler-Token` |
| GET/POST | `/api/notifications...` | o'z xabarlari |
| GET | `/api/dashboard/summary`, `/health` | auth / ochiq |

## Risk algoritmi
`risk = 0.5·(100−ball) + 0.3·(100−davomat) + 0.2·trend` · LOW <30 · MEDIUM <50 · HIGH <70 · CRITICAL ≥70. Batafsil: `docs/01_talablar.md`.

## GitHub'ga yuklash
```bash
cd student-performance-monitoring-system
git init -b main
git config user.name "Supervisor"
git config user.email "nabdurazaqov@gmail.com"
git add .
git commit -m "Initial commit: student performance monitoring system"

# 1-usul: GitHub CLI (https://cli.github.com), avval: gh auth login
gh repo create student-performance-monitoring-system --public --source=. --remote=origin --push

# 2-usul: github.com'da bo'sh repo yarating (README/.gitignore qo'shmasdan), keyin:
git remote add origin https://github.com/Supervisor/student-performance-monitoring-system.git
git push -u origin main
```
Havola: `https://github.com/Supervisor/student-performance-monitoring-system`. O'qituvchiga shu havolani (va Cloud Run URL'ni) yuboring; repo **private** bo'lsa, o'qituvchini Settings → Collaborators orqali qo'shing.
> Agar `Supervisor` nomi band yoki boshqa akkaunt bo'lsa, havoladagi username'ni o'z akkauntingizga almashtiring.

## Cloud
GCP deployment: `docs/03_cloud_gcp.md`.

## Hujjatlar
`docs/01_talablar.md` · `docs/02_arxitektura.md` · `docs/03_cloud_gcp.md` · `docs/04_himoya.md` (20 savol-javob) · `docs/05_testlar_checklist.md` · `docs/diagrams/`
